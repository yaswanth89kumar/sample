<?php

namespace Drupal\ctools;


class ContextNotFoundException extends \Exception {}
